import o from"../lib/core.js";export{default as HighlightJS,default}from"../lib/core.js";
