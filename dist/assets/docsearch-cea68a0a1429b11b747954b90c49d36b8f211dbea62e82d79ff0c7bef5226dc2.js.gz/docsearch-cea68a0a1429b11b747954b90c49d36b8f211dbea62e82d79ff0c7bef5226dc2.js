import '@docsearch/js';

docsearch({
  container: '#docsearch',
  appId: 'LEN50BR1UK',
  indexName: 'trailblazer-website-24',
  apiKey: 'b1f311e280db1c40850ee82e08eb3449'
});
